from django.contrib import admin
from .models import MenuItem,Category,Rating,Booking,UserComments,Registeration
# Register your models here.
admin.site.register(MenuItem)
admin.site.register(Category)
admin.site.register(Rating)
admin.site.register(Booking)
admin.site.register(UserComments)
admin.site.register(Registeration)