from django.urls import path
from rest_framework.authtoken.views import obtain_auth_token
from . import views

urlpatterns=[
    path('menu-items/',views.menu_item),
    path('secret/',views.secret),
    path('api-token-auth',obtain_auth_token),
    path('me/',views.me),
    path('ratings', views.RatingsView.as_view()),
    path('manager-view/',views.manager_view),
    path('throttle-check/',views.throttle_check),
    path('throttle-check-auth/',views.throttle_check_auth),
    path('groups/managers/users',views.managers),
    path('blog/',views.form_view,name='blog'),
    path('booking_form/',views.booking_form,name='booking_form'),
    path('booking_list/',views.booking_list,name='booking_list'),
    path('registration_form/',views.registeration_form,name='registeration_form'),
]