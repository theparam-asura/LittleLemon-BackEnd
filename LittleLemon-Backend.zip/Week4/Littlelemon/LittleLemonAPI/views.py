from datetime import date
from django.shortcuts import render,get_object_or_404,redirect
from rest_framework.response import Response
from rest_framework.decorators import api_view,renderer_classes
from .models import MenuItem,Rating,UserComments
from .serializers import MenuItemSerializer, RatingSerializer
from rest_framework import status
from rest_framework.views import APIView
from django.views import View
from django.core.paginator import Paginator,EmptyPage
from rest_framework.permissions import IsAuthenticated,IsAdminUser
from rest_framework.decorators import permission_classes
from rest_framework.decorators import throttle_classes
from rest_framework.throttling import UserRateThrottle, AnonRateThrottle, SimpleRateThrottle
from rest_framework import generics
from django.contrib.auth.models import User,Group
from LittleLemonAPI.forms import CommentForm
from django.http import JsonResponse
from .models import Booking,Registeration
from .forms import BookingForm,RegistrationForm
from django.http import HttpResponse
# Create your views here.














@api_view(['GET','POST'])
def menu_item(request):
    if(request.method=='GET'):
        items=MenuItem.objects.select_related('category').all()
        category_name=request.query.params.get('category')
        to_price=request.query.params.get('to_price')
        search=request.query.params.get('search')
        searchindex=request.query.params.get('searchindex')
        ordering=request.query.params.get('ordering')
        perpage=request.query.params.get('perpage',default=2)
        page=request.query.params.get('page',default=1)
        if category_name:
            items.filter(category_title=category_name)
        if to_price:
            items.filter(price_lte=to_price)
        if search:
            items.filter(title_startswith=search)
        if searchindex:
            items.filter(tiltle_contains=searchindex)
        if ordering:
            orderingfields=ordering.split(",")
            items=items.order_by(*orderingfields)
            # items=items.order_by(ordering)
        if category_name:
            items.filter(category_title=category_name)
        paginator=Paginator(items,per_page=perpage)
        try:
            items=paginator.page(number=page)
        except EmptyPage:
            item=[]
        serialized_item=MenuItemSerializer(items,many=True)
        return Response(serialized_item.data)
    elif request.method=='POST':
        serialized_item=MenuItemSerializer(data=request.data)
        serialized_item.is_valid(raise_exception=True)
        serialized_item.save()
        return Response(serialized_item.validated_data,status.HTTP_201_CREATED)



@api_view
def single_item(request,id):
    item=get_object_or_404(MenuItem,pk=id)
    serialized_item=MenuItemSerializer(item)
    return Response(serialized_item.data)



# @api_view()
# @permission_classes([IsAuthenticated])
# @throttle_classes([TenCallsPerminute])
# def throttle_check_auth(request):
#     return Response({"message":"only manager should see this"})




@api_view()
@permission_classes([IsAuthenticated])
def me(request):
    return Response(request.user.email)









def secret(request):
    return Response({"Some secret text":"Ullu bnaya bda mja aaya"})

@api_view()
@permission_classes([IsAuthenticated])
def secret(request):
    return Response({"Some secret text":"Ullu bnaya bda mja aaya"})


@api_view()
@permission_classes([IsAuthenticated])
def manager_view(request):
    return Response({"Some secret text":"Only manager should see this"})






@api_view()
@throttle_classes([AnonRateThrottle])
def throttle_check(request):
  return Response({"message":"successful"})


@api_view()
@permission_classes([IsAuthenticated])
@throttle_classes([UserRateThrottle])
def throttle_check_auth(request):
  return Response({"message":"successful"})



class RatingsView(generics.ListCreateAPIView):
    queryset = Rating.objects.all()
    serializer_class = RatingSerializer

    def get_permissions(self):
        if(self.request.method=='GET'):
            return []

        return [IsAuthenticated()]






@api_view(['POST'])
@permission_classes([IsAdminUser])
def managers(request):
    username=request.data['username']
    if username:
        user=get_object_or_404(user,username=username)
        managers=Group.objects.get(name="managers")
        if request.method=='POST':
            managers.user_set.add(user)
        elif request.method=='DELETE':
            managers.user_set.remove(user)
        return Response({"message":"ok"})
    return Response({"message":"error"},status.HTTP_400_BAD_REQUEST)






def form_view(request):
    form=CommentForm()
    if request.method=='POST':
        form=CommentForm(request.POST)
        if form.is_valid():
            cd=form.cleaned_data
            uc=UserComments(
                first_name=cd['first_name'],
                last_name=cd['last_name'],
                comment=cd['comment'],
            )
            uc.save()
            return JsonResponse({
                'message':'success'
            })
    return render(request,'blog.html',{'form':form})


def booking_form(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('booking_list')
    else:
        form = BookingForm()

    return render(request,'booking_form.html', {'form': form})

def booking_list(request):
    bookings = Booking.objects.all()
    return render(request,'booking_list.html', {'bookings': bookings})


def registeration_form(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("Logged In welcome to little lemon restraunt")
    else:
        form = RegistrationForm()

    return render(request,'register.html', {'form': form})
