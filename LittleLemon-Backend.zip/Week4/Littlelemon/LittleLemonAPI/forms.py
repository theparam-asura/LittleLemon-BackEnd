from django import forms
from .models import UserComments,Booking,Registeration


class CommentForm(forms.ModelForm):
    class Meta:
        model=UserComments
        fields='__all__'



class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['first_name', 'reservation_date', 'reservation_slot']


class RegistrationForm(forms.ModelForm):
    class Meta:
        model=Registeration
        fields='__all__'
