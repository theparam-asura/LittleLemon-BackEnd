from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Category(models.Model):
    slug=models.SlugField()
    title=models.CharField(max_length=200)
    def __str__(self)->str:
        return self.title



class MenuItem(models.Model):
    title=models.CharField(max_length=200)
    price=models.IntegerField()
    inventory=models.SmallIntegerField()
    category=models.ForeignKey(Category,on_delete=models.PROTECT,default=1)

class Rating(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    menuitem_id =  models.SmallIntegerField()
    rating = models.SmallIntegerField()


class UserComments(models.Model):
    first_name=models.CharField(max_length=200)
    last_name=models.CharField(max_length=200)
    comment=models.CharField(max_length=100)


class Booking(models.Model):
    first_name = models.CharField(max_length=255)
    reservation_date = models.DateField()
    reservation_slot = models.TimeField()

    def __str__(self):
        return self.first_name
    class Meta:
        unique_together = ('reservation_date', 'reservation_slot')





class Registeration(models.Model):
    email = models.EmailField()
    password = models.CharField(max_length=200)

    def __str__(self):
        return self.email
    class Meta:
        unique_together= ('email','password')
